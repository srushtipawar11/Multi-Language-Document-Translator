MULTI-LANGUAGE DOCUMENT TRANSLATOR - BACKEND

This version keeps the translator workflow and adds login/logout.

Demo login:
Username: admin
Password: admin123

Backend files:
- app.py
- services/database.py
- services/document_service.py
- services/translation_service.py
- services/__init__.py
- requirements.txt

IMPORTANT:
This package expects templates/login.html for the new login page.
Your existing index.html and history.html can remain.

Run from the project root:
python app.py

Then open:
http://127.0.0.1:5000

Do not replace your working project until you have a backup.
