import os
from pathlib import Path
from functools import wraps

from flask import Flask, flash, redirect, render_template, request, send_from_directory, session, url_for
from werkzeug.utils import secure_filename

from services.database import init_db, add_translation, get_translations, authenticate_user
from services.document_service import extract_document, build_translated_docx
from services.translation_service import translate_text

BASE_DIR = Path(__file__).resolve().parent
UPLOAD_DIR = BASE_DIR / "uploads"
OUTPUT_DIR = BASE_DIR / "outputs"
DATABASE_PATH = BASE_DIR / "translator.db"

ALLOWED_EXTENSIONS = {"pdf", "docx", "txt"}
MAX_FILE_SIZE = 10 * 1024 * 1024

LANGUAGES = {
    "English": "en", "Hindi": "hi", "Kannada": "kn", "Tamil": "ta",
    "Telugu": "te", "Malayalam": "ml", "Marathi": "mr", "Bengali": "bn",
    "Gujarati": "gu", "Punjabi": "pa", "Urdu": "ur", "Arabic": "ar",
    "French": "fr", "German": "de", "Spanish": "es", "Italian": "it",
    "Portuguese": "pt", "Russian": "ru", "Japanese": "ja", "Korean": "ko",
    "Chinese": "zh-CN"
}

app = Flask(__name__)
app.config["SECRET_KEY"] = os.environ.get("SECRET_KEY", "change-this-in-production")
app.config["MAX_CONTENT_LENGTH"] = MAX_FILE_SIZE

UPLOAD_DIR.mkdir(exist_ok=True)
OUTPUT_DIR.mkdir(exist_ok=True)
init_db(DATABASE_PATH)


def allowed_file(filename):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS


def login_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if "user_id" not in session:
            flash("Please log in first.", "error")
            return redirect(url_for("login"))
        return view(*args, **kwargs)
    return wrapped


@app.errorhandler(413)
def too_large(_error):
    flash("File is too large. Maximum size is 10 MB.", "error")
    return redirect(url_for("index"))


@app.route("/login", methods=["GET", "POST"])
def login():
    if "user_id" in session:
        return redirect(url_for("index"))

    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        user = authenticate_user(DATABASE_PATH, username, password)

        if user:
            session.clear()
            session["user_id"] = user["id"]
            session["username"] = user["username"]
            flash("Login successful.", "success")
            return redirect(url_for("index"))

        flash("Invalid username or password.", "error")

    return render_template("login.html")


@app.route("/logout")
def logout():
    session.clear()
    flash("You have been logged out.", "success")
    return redirect(url_for("login"))


@app.route("/")
@login_required
def index():
    return render_template(
        "index.html",
        languages=LANGUAGES,
        history=get_translations(DATABASE_PATH),
        username=session.get("username"),
    )


@app.post("/translate")
@login_required
def translate():
    uploaded = request.files.get("document")
    source = request.form.get("source", "auto")
    target = request.form.get("target", "")

    if not uploaded or not uploaded.filename:
        flash("Please choose a document.", "error")
        return redirect(url_for("index"))

    if not target:
        flash("Please select a target language.", "error")
        return redirect(url_for("index"))

    if source == target and source != "auto":
        flash("Source and target must be different.", "error")
        return redirect(url_for("index"))

    if not allowed_file(uploaded.filename):
        flash("Only PDF, DOCX and TXT files are supported.", "error")
        return redirect(url_for("index"))

    safe_name = secure_filename(uploaded.filename)
    input_path = UPLOAD_DIR / safe_name
    uploaded.save(input_path)

    try:
        paragraphs = extract_document(input_path)
        if not any(p.strip() for p in paragraphs):
            raise ValueError("No selectable text found. Scanned PDFs may require OCR.")

        translated = [
            translate_text(p, source, target) if p.strip() else ""
            for p in paragraphs
        ]

        output_name = f"{Path(safe_name).stem}_{target}_translated.docx"
        build_translated_docx(translated, OUTPUT_DIR / output_name)

        add_translation(DATABASE_PATH, safe_name, source, target, output_name, "Completed")
        flash("Translation completed successfully.", "success")
        return redirect(url_for("download", filename=output_name))

    except Exception as exc:
        add_translation(DATABASE_PATH, safe_name, source, target, "", f"Failed: {exc}")
        flash(f"Translation failed: {exc}", "error")
        return redirect(url_for("index"))


@app.get("/download/<path:filename>")
@login_required
def download(filename):
    return send_from_directory(OUTPUT_DIR, filename, as_attachment=True)


@app.get("/history")
@login_required
def history():
    return render_template(
        "history.html",
        history=get_translations(DATABASE_PATH),
        username=session.get("username"),
    )


if __name__ == "__main__":
    app.run(debug=True)
