from deep_translator import GoogleTranslator

MAX_CHARS = 3500


def split_text(text, max_chars=MAX_CHARS):
    words = text.split()
    chunks, current = [], ""

    for word in words:
        candidate = f"{current} {word}".strip()
        if len(candidate) <= max_chars:
            current = candidate
        else:
            if current:
                chunks.append(current)
            current = word

    if current:
        chunks.append(current)
    return chunks


def translate_text(text, source, target):
    if not text.strip() or (source == target and source != "auto"):
        return text

    translator = GoogleTranslator(source=source, target=target)
    return " ".join(translator.translate(chunk) for chunk in split_text(text))
