import sqlite3
from werkzeug.security import check_password_hash, generate_password_hash


def get_connection(db_path):
    con = sqlite3.connect(str(db_path))
    con.row_factory = sqlite3.Row
    return con


def init_db(db_path):
    con = get_connection(db_path)

    con.execute('''
        CREATE TABLE IF NOT EXISTS translations (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            original_filename TEXT NOT NULL,
            source_language TEXT NOT NULL,
            target_language TEXT NOT NULL,
            output_filename TEXT,
            status TEXT NOT NULL,
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        )
    ''')

    con.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT NOT NULL UNIQUE,
            password_hash TEXT NOT NULL,
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        )
    ''')

    # Demo login: admin / admin123
    existing = con.execute(
        "SELECT id FROM users WHERE username = ?", ("admin",)
    ).fetchone()

    if existing is None:
        con.execute(
            "INSERT INTO users (username, password_hash) VALUES (?, ?)",
            ("admin", generate_password_hash("admin123")),
        )

    con.commit()
    con.close()


def authenticate_user(db_path, username, password):
    con = get_connection(db_path)
    row = con.execute(
        "SELECT id, username, password_hash FROM users WHERE username = ?",
        (username,),
    ).fetchone()
    con.close()

    if row and check_password_hash(row["password_hash"], password):
        return {"id": row["id"], "username": row["username"]}
    return None


def add_translation(db_path, original_filename, source_language,
                    target_language, output_filename, status):
    con = get_connection(db_path)
    con.execute('''
        INSERT INTO translations
        (original_filename, source_language, target_language, output_filename, status)
        VALUES (?, ?, ?, ?, ?)
    ''', (original_filename, source_language, target_language, output_filename, status))
    con.commit()
    con.close()


def get_translations(db_path):
    con = get_connection(db_path)
    rows = con.execute(
        "SELECT * FROM translations ORDER BY id DESC"
    ).fetchall()
    con.close()
    return rows
