from pathlib import Path
from docx import Document
from pypdf import PdfReader


def extract_pdf(path):
    reader = PdfReader(str(path))
    paragraphs = []

    for page in reader.pages:
        text = page.extract_text() or ""
        if text.strip():
            paragraphs.append(text)

    return paragraphs


def extract_docx(path):
    document = Document(str(path))
    return [p.text for p in document.paragraphs]


def extract_txt(path):
    return [Path(path).read_text(encoding="utf-8")]


def extract_document(path):
    path = Path(path)
    ext = path.suffix.lower()

    if ext == ".pdf":
        return extract_pdf(path)
    if ext == ".docx":
        return extract_docx(path)
    if ext == ".txt":
        return extract_txt(path)

    raise ValueError(f"Unsupported file type: {ext}")


def build_translated_docx(paragraphs, output_path):
    document = Document()
    for paragraph in paragraphs:
        document.add_paragraph(paragraph)
    document.save(str(output_path))
